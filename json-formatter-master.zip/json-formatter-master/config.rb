css_dir = "extension/css"
sass_dir = "sass"
preferred_syntax = :scss
output_style = :compressed
